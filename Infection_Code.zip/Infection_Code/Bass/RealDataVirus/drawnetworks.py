#!/usr/bin/env python

import sys
import networkx as nx
from pylab import *


def drawNetwork(G,edgeAlpha=0.25,edgeColor='#000000'):
	figure()
	pos = nx.pygraphviz_layout(G,'neato')
	nx.draw_networkx_edges(G,pos,alpha=edgeAlpha,edge_color=edgeColor)
	nx.draw_networkx_nodes(G,pos, node_size=[3 * G.degree(n) for n in G], node_color='#0088FF',alpha=0.5)
	xs,ys = zip(*pos.values())
	xspan = max(xs) - min(xs)
	yspan = max(ys) - min(ys)
	xlim(min(xs) - 0.1*xspan, max(xs) + 0.1*xspan)
	ylim(min(ys) - 0.1*yspan, max(ys) + 0.1*yspan)
	axis('off')
	
	#nx.draw(G,pos,with_labels=False,alpha=0.8,node_size=25,edge_color='#555555',node_color='#0088FF',edge_alpha=0.1)


fname="alumni_undirected_connected.edgelist"
G = nx.read_weighted_edgelist(fname)
drawNetwork(G,edgeAlpha=0.8,edgeColor='#555555')
savefig(fname.replace(".edgelist","" + ".drawing.png"),dpi=300)

fnames = ["powerBA_k14.edgelist", "erdos_expected13343.edgelist", "smallworld_rewire0.01_k26.edgelist", "lattice_k26.edgelist", "twitter_bfs.edgelist"]

for fname in fnames:
	G = nx.read_edgelist(fname)
	drawNetwork(G)
	savefig(fname.replace(".edgelist","" + ".drawing.png"),dpi=300)
