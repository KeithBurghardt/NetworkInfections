#!/usr/bin/env python

import sys
import networkx as nx
from pylab import *

#~ from optparse import OptionParser
#~ parser = OptionParser()
#~ (options, args) = parser.parse_args()

def twoStepNeighbors(G,n):
	"""other nodes (not counting the node itself) within a 2-step radius of the given node n"""
	return [ y for y in reduce(lambda x,y: x+y, [G.neighbors(x) for x in ([n] + G.neighbors(n))]) if y != n]
	#return [y for y in flatten(G.neighbors(x) for x in ([n] + G.neighbors(n))) if y != n]

if float(nx.version.__version__) < 1.1:
	sys.stderr.write("PROBLEM: needs networkx version 1.1 or greater!")
	sys.exit(1)

G = nx.read_edgelist(sys.stdin)
indices = {}
for i in xrange(len(G.nodes())):
	indices[G.nodes()[i]] = i

sys.stdout.write("#num-nodes\n%s\n"%len(G.nodes()))
sys.stdout.write("#num-links\n%s\n"%len(G.edges()))
sys.stdout.write("#links\n")

for e in G.edges():
	sys.stdout.write("%s %s\n"%(indices[e[0]],indices[e[1]]))

sys.stdout.write("#node stats\n")

path_lengths = nx.all_pairs_shortest_path_length(G)
clustering = nx.clustering(G)
degree = nx.degree(G)


for n in G.nodes():
	myAPL = mean([x for x in path_lengths[n].values() if x != 0])
	sys.stdout.write("%s %s %s %s %s\n"%(indices[n],myAPL,clustering[n],degree[n],len(twoStepNeighbors(G,n))))
