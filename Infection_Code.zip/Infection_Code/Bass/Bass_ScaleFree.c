//////////////////////Scale Free Sparse Graph///////////////////////////
//Written By: Keith Burghardt
//Most Recent Update: 10/12/2013

/*
 This is code for the fraction of infected nodes at each timestep, using the formula:
 
	 \Delta \rho = -R \rho + I <k> \rho (1-\rho)				(1)
 
 (SIS Homogeneous Mixing Hypothesis) where we update continuously.
 
 Code computes behavior space of formula for:
	- I	= I_MIN		:I_STEP_SIZE		:I_MAX,
	- R 	= R_MIN		:R_STEP_SIZE		:R_MAX, 
	- <k>	= ALPHA_MIN	:ALPHA_STEP_SIZE	:ALPHA_MAX

 with NUMBER_OF_TRIALS (make this >= the number of processors).
 
 input definitions:
 	RUN_TIME,
 	NUMBER_OF_NODES,  
 	ALPHA_MIN, ALPHA_MAX  ALPHA_STEP_SIZE;
 	I_MIN,      I_MAX,      I_STEP_SIZE;
 	R_MIN,      R_MAX,      R_STEP_SIZE;
 
 
 output:
	"name.dat": " Alpha_min = , Alpha_max, Alpha_step_size= ,
		 R= ... , I= ... , # Trials =__  \n" 
	then array: "fraction_infected " x Run_Time x # I's x # R's x # Alpha steps
 
 
 NOTES: 
	- FOR BEST QUALITY:
		- compile with "$ gcc -Wall -O3 -pthread 
                        -Wl,-rpath=/export/data/ccbdata/keith/gsl.1.16/lib 
                        -L/export/data/ccbdata/keith/gsl.1.16/lib -lgsl -lgslcblas -lm
                        -I/export/data/ccbdata/keith/gsl.1.16/include -funroll-loops
                        [maybe -fvariable-expansion-in-unroller] -oHMM_ICS FILE.c
		- allocate memory in parallel with Hoard, or similar
	

	- Behavior Space determined by definitions below. 
 
 */
////////////////////////////////////////////////////////////////////////////////

#include "SIS_ScaleFree.h"

//Computation Runs for RUN_TIME number of ticks,
//for equilibrium we ignore first 504 ticks
#define RUN_TIME        (4600)
#define IGNORE_TIME     (504)//For Cooley-Turkey method, data is of length 2^12
#define FFT_START       (100)// lowest frequency where pink noise
// slope doesn't flatten out
#define FFT_END         (1800)//highest frequency before slope flattens out

//graph features
#define NUMBER_OF_NODES	(100000)
#define K_MIN           (2) //minimal degree

#define ALPHA_MIN       (2.0)
#define ALPHA_MAX       (3.0)
#define ALPHA_STEP_SIZE (0.2)

//behavior space parameters
#define I_MIN          	(0.01f)
#define I_MAX          	(1.0f)
#define I_STEP_SIZE   	(0.01f)

#define R_MIN           (0.2f)
#define R_MAX           (0.8f)
#define R_STEP_SIZE     (0.2f)


#define eps             (0.000001)

#define NUMBER_OF_TRIALS (144)


//infection conditions
#define INFECTED        (1)

#define SUSCEPTIBLE     (0)



int main(int argc, char** argv)
{
    
    time_and_run_behavior_space();
    
    return 0;
}
void time_and_run_behavior_space()

{
    
    clock_t start = clock();//timer
    clock_t end;
    clock_t time;
    struct timeval actual_start;
    struct timeval actual_end;
    int actual_time;
    gettimeofday(&actual_start,NULL);
    
    //write to this file
    char *file = "/export/data/ccbdata/keith/Bassalpha=2:0.2:3N=10^5R=0.2:0.2:0.8,I=0.01:0.01:1.0,36TrialsEach.dat";

    behavior_space(file);
    end=clock();
    time = end-start;
    gettimeofday(&actual_end,NULL);
    actual_time = actual_end.tv_sec-actual_start.tv_sec;
    printf("Total Time: %ld ms (clock cycles) or %i sec (actual)\n",time/(CLOCKS_PER_SEC/1000),actual_time);
    
}


void behavior_space (char* file)
{
    //we make several for loops to observe entire behavior space, e.g.
    //      -alpha
    //      -infection probability (I)
    //      -recovery probability (R)
    FILE * p = NULL;
    
    p = fopen(file, "w");//in order to write everything on ONE text file, we open the file here
    if(p==NULL)
    {
        printf("Error opening file: %s",file);
        exit(1);
    }
    
    fprintf(
            p,
            "Alpha:%lf:%lf:%lf, R=%f:%f:%f, I=%f:%f:%f, Trials=%i\n",
            ALPHA_MIN,          ALPHA_STEP_SIZE,            ALPHA_MAX,
            R_MIN,              R_STEP_SIZE,                R_MAX,
            I_MIN,              I_STEP_SIZE,                I_MAX,
            NUMBER_OF_TRIALS);
    
    int I_steps             = (int)((I_MAX-I_MIN)/I_STEP_SIZE+1+eps);
    int R_steps             = (int)((R_MAX-R_MIN)/R_STEP_SIZE+1+eps);
    int Alpha_steps 	    = (int)((ALPHA_MAX-ALPHA_MIN)/ALPHA_STEP_SIZE+1+eps);
    
    pthread_t threads [NUMBER_OF_TRIALS];
    thread_args trial [NUMBER_OF_TRIALS];
    
    int rc;
    int TRIAL;
    double ALPHA;
    int count=0;
    for (ALPHA =  ALPHA_MIN;
         ALPHA <= ALPHA_MAX+eps;
         ALPHA += ALPHA_STEP_SIZE)
    {
        
        for (TRIAL=count*NUMBER_OF_TRIALS/Alpha_steps;
             //divide number of trials into almost equal parts and make threads
             // then, on the last count (count+1==Alph_steps) continue to the end
             (TRIAL<(count+1)*NUMBER_OF_TRIALS/Alpha_steps && count+1<Alpha_steps)
             ||(count+1 == Alpha_steps && TRIAL<NUMBER_OF_TRIALS);
             ++TRIAL)
        {
            make_thread_args(&trial[TRIAL],
                             TRIAL,
                             NUMBER_OF_NODES,
                             ALPHA);
            rc = pthread_create(&threads[TRIAL],
                                NULL,
                                perform_trials,
                                (void *) &trial[TRIAL]);
            assert(0 == rc);
        }
        count++;
    }
    count		    =  0;    
    for (ALPHA =  ALPHA_MIN;
         ALPHA <= ALPHA_MAX+eps;
     	 ALPHA += ALPHA_STEP_SIZE)
    {
        
     	for (TRIAL=count*NUMBER_OF_TRIALS/Alpha_steps;
             //divide number of trials into almost equal parts and make threads
             // then, on the last count (count+1==Alph_steps) continue to the end
             (TRIAL<(count+1)*NUMBER_OF_TRIALS/Alpha_steps && count+1<Alpha_steps)
             ||(count+1 == Alpha_steps && TRIAL<NUMBER_OF_TRIALS);
             ++TRIAL)
        {
            rc= pthread_join(threads[TRIAL],(void *)&trial[TRIAL]);
            assert(0 == rc);
        }
        
        int i,R;
        double average, slope;
        fprintf(p,"\n");
        for (R=0; R<R_steps;++R)
        {
            fprintf(p,"\n");
            for (i=0; i<I_steps;++i)
            {
                
                for (TRIAL=count*NUMBER_OF_TRIALS/Alpha_steps;
                     //divide number of trials into almost equal parts and make threads
                     // then, on the last count (count+1==Alph_steps) continue to the end
                     (TRIAL<(count+1)*NUMBER_OF_TRIALS/Alpha_steps && count+1<Alpha_steps)
                     ||(count+1 == Alpha_steps && TRIAL<NUMBER_OF_TRIALS);
                     ++TRIAL)
                {
                    average =trial[TRIAL].FractionInfectedVersusTime[RUN_TIME*(R*I_steps+i)+IGNORE_TIME]/(RUN_TIME-IGNORE_TIME);
                    slope = trial[TRIAL].Trend[i + R*I_steps];
                    
                    fprintf(p,"%lf\t%lf\n",average, slope);
                    //printf("\n\n%lf\n\n",average);//print average
                }
                
            }
        }
        
        fprintf(p,"\n\n");
        for (TRIAL=count*NUMBER_OF_TRIALS/Alpha_steps;
             //divide number of trials into almost equal parts and make threads
             // then, on the last count (count+1==Alph_steps) continue to the end
             (TRIAL<(count+1)*NUMBER_OF_TRIALS/Alpha_steps && count+1<Alpha_steps)
             ||(count+1 == Alpha_steps && TRIAL<NUMBER_OF_TRIALS);
             ++TRIAL)
        {
            fprintf(p,"\n");
            
            printf("Alpha: %f, Trial: %i\n",ALPHA,TRIAL);
            //a different graph for each trial
            int i;
            for (i=0; i<trial[TRIAL].G.NumNodes; ++i)
            {
                if(trial[TRIAL].G.nodes[i].degree==0)
                    fprintf(p,"NULL");
                else
                {
                    int j;
                    for(j=0; j<trial[TRIAL].G.nodes[i].degree;++j)
                    {
                        fprintf(p,"%i ",trial[TRIAL].G.nodes[i].neighbors[j]);
                    }
                }
                fprintf(p,"\n");
            }
            
            free_thread_args(&trial[TRIAL]);
        }
        count++;
    }
    printf("\nWritten Successfully to: %s\n",file);
    fclose(p);
}

////////////////////////////////////////////////////////////
//following function was partly barrowed from stackoverflow forum
void seed_rand(int thread_n, gsl_rng* r)
{
    struct timeval tv;
    
    gettimeofday(&tv, NULL);
    gsl_rng_set(r,tv.tv_sec * thread_n + tv.tv_usec);
}
////////////////////////////////////////////////////////////

void* perform_trials(void* trial)
{
    thread_args* t = (thread_args *) trial;//equate pointers
    
    ////////////////////VARIABLES FOR DATA ANALYSIS/////////////////////
    size_t STRIDE =1;//steps of size "double"
    double * fft;
    //allocate appropriate memory
    double * x = malloc(sizeof(double)*(RUN_TIME-IGNORE_TIME)/2);
    double * y = malloc(sizeof(double)*(RUN_TIME-IGNORE_TIME)/2);
    double constant,slope;//best fit parameters
    double cov00, cov01, cov11;//covariance matrix
    double sumsq; //sum of the square of all terms
    int count=0;
    ////////////////////////////////////////////////////////////////////
    int I_steps             = ((int)((I_MAX-I_MIN)/I_STEP_SIZE+1+eps));
    int R_steps             = ((int)((R_MAX-R_MIN)/R_STEP_SIZE+1+eps));
    float R;
    for (R = R_MIN; R<=R_MAX+eps;R+=R_STEP_SIZE)//R ={0.1...1.0} in steps of 0.1
    {
        float I;
        for (I=I_MIN; I<=I_MAX+eps; I+=I_STEP_SIZE)//I = {0.0...1.0} in steps of 0.01
        {
            // To find correct position to record values for the
            // FractionInfectedVersusTime array, we use
            // the following variables:

            int   Beginning_Of_Array     = RUN_TIME*count;
            
            run_experiment (t->FractionInfectedVersusTime,
                            Beginning_Of_Array,
                            &t->G,
                            I,
                            R,
                            t->r);
            /////////////////////// DATA ANALYSIS /////////////////////
            
            //take on values of "fraction infected"
            //from TIME_IGNORE to the end of the run
            //IF the infection last to the end of the run
            if (t->FractionInfectedVersusTime[Beginning_Of_Array+RUN_TIME-1]!=0)
            {
                fft = t->FractionInfectedVersusTime+Beginning_Of_Array+IGNORE_TIME;
                int n = RUN_TIME-IGNORE_TIME;
                gsl_fft_real_radix2_transform (fft, STRIDE, RUN_TIME-IGNORE_TIME);
                //printf("avg: %lf \n",fft[0]/n);
                int j;
                for (j=1; j<n/2;j++)//we skip j=0 to avoid "log(0)"
                {
                    x[j] = gsl_sf_log ((double) j);
                    //we take the log of the absolute value of the fft
                    //note that the fft contains the real and complex part
                    //on opposite sizes of the array

                    if((fft[j]*fft[j] + fft[n-j]*fft[n-j])>0.0)//log well defined
                    {
                        y[j] = gsl_sf_log (fft[j]*fft[j] + fft[n-j]*fft[n-j]);
                        //if j==n/2
                        //  y[j] = gsl_sf_log(fft[n/2]*fft[n/2]);//imaginary part is 0
                    }
                    else y[j] = -999999;//set to "-infinity"
                }
               
                gsl_fit_linear (x+FFT_START,
                                STRIDE,
                                y+FFT_START, STRIDE,
                                FFT_END-FFT_START,
                                &constant,
                                &slope,
                                &cov00, &cov01, &cov11,
                                &sumsq);
                //printf("average %lf\n",fft[0]/(RUN_TIME-IGNORE_TIME));
                t->Trend[count] = -slope;
            }
            else//infection died out
            {
                //set slop to 0
                t->Trend[count] = 0.0;
                //set average to 0
                t->FractionInfectedVersusTime[Beginning_Of_Array+IGNORE_TIME]=0.0;
            }
            count++;
        }
    }
    // remove allocated memory
    free((double*) x);
    free((double*) y);
}



void run_experiment (double * 		FractionInfectedVersusTime_ptr,
                     int 			start,
                     graph *	 		G,
                     float 			I,
                     float 			R,
                     gsl_rng *  		r)
{
    
    
    double FRACTION_INFECTED       = 0.5;//We infect half of our nodes initially
 //   double FRACTION_HEALTHY        = 1-FRACTION_INFECTED;
    int   NUMBER_INFECTED         = (int)(FRACTION_INFECTED*NUMBER_OF_NODES);
    int   INITIAL_NUMBER_INFECTED = NUMBER_INFECTED;//(int)(NUMBER_OF_NODES*FRACTION_INFECTED);
    int i;
    for(i = 0; i < NUMBER_OF_NODES; i++)
    {
        if(i<INITIAL_NUMBER_INFECTED)//infect 1/2 of all nodes
            G->nodes[i].infected = INFECTED;//Infect 1/2 of all nodes
    }
    int t;
    for (t=0; t<RUN_TIME; ++t)
    {
        
        if(FRACTION_INFECTED>0.0)
        {
            infect (G,I,r);
            recover (G, &NUMBER_INFECTED, R,r);
            
            FRACTION_INFECTED = NUMBER_INFECTED/(double)NUMBER_OF_NODES;
       //     FRACTION_HEALTHY =1-FRACTION_INFECTED;

            //store fraction of infected
            //"start" is starting position of array
            FractionInfectedVersusTime_ptr[start+t] = FRACTION_INFECTED;
        }
        else//if all nodes are healthy
        {
            FractionInfectedVersusTime_ptr[start+t] = 0.0;
        }
        
    }
    
}

void infect (graph *    G,
             float      I,
             gsl_rng *  r)
{
    double rand;
    int i,j,n;
    for(i=0; i<G->NumNodes; ++i)
    {   //if node is healthy
        if(G->nodes[i].infected==SUSCEPTIBLE)
        {   //look at its neighbors
	    n=0;
            for(j=0; j< G->nodes[i].degree;++j)
            {
                int neighbor=G->nodes[i].neighbors[j];
                if(G->nodes[neighbor].infected==INFECTED)
		    n++;
	    }
            double rand = gsl_rng_uniform (r);
            if(rand<I*n/(double)G->nodes[i].degree)
                G->nodes[i].infected=INFECTED;
        }
    }
}

void recover (graph * G,
	      int *NUMBER_INFECTED, 
	      float R,
	      gsl_rng* r)

{
    *NUMBER_INFECTED = 0;
    double rand;
    int k;
    for(k=0; k<NUMBER_OF_NODES; ++k)
    {
        if (G->nodes[k].infected==INFECTED)//if infected
        {
            double rand = gsl_rng_uniform (r);
            if(rand<R)
            {
                G->nodes[k].infected=SUSCEPTIBLE;//recover with probability R
            }
            else *NUMBER_INFECTED+=1;//else this is an infected node, so record
        }
    }
}
void make_thread_args (	thread_args * args,
                       	int thread,
                        int N,
                        double alpha)
{
    args->thread                    = thread;
    //buffer for mercenne twister
    args->r                         = gsl_rng_alloc (gsl_rng_mt19937);
    seed_rand(thread,args->r);
    make_graph(&(args->G),N,alpha,args->r);
    int I_steps             = ((int)((I_MAX-I_MIN)/I_STEP_SIZE+1+eps));
    int R_steps             = ((int)((R_MAX-R_MIN)/R_STEP_SIZE+1+eps));
    
    int BEHAVIOR_SPACE              = (RUN_TIME*(I_steps*R_steps));
    args->FractionInfectedVersusTime= malloc(sizeof(double)*BEHAVIOR_SPACE);//allocate for all of behavior space
    args->Trend                     = malloc(sizeof(double)*I_steps*R_steps);
    
}
void free_thread_args (thread_args * args)
{
    free(args->FractionInfectedVersusTime);
    free(args->Trend);
    gsl_rng_free (args->r);
    free_graph(&(args->G));
}

void make_node (node* n, int ID, int deg)
{
    n->ID = ID;
    n->degree=deg;
    n->current_number_of_neighbors = 0;
    n->infected = SUSCEPTIBLE;
    n->neighbors = malloc(sizeof(int)*deg);
}

void free_node (node* n)
{
    free(n->neighbors);
}

void make_graph (graph* G,
                int N,
                double ALPHA,
                gsl_rng* r)
{
    G->NumNodes = N;
    G->alpha = ALPHA;
    G->nodes = malloc(sizeof(node)*N);
    int i;
    for (i=0; i<N; ++i)
    { 
        int node_degree = ran_scale_free(r,K_MIN,ALPHA);
       
        make_node(&(G->nodes[i]),i,node_degree);
    }
    for (i=0; i<N; ++i)
    {
        if (G->nodes[i].current_number_of_neighbors
            <G->nodes[i].degree)
        {
        //create random neighbors
            int j, neighbor, neighbors_number_of_neighbors;
            for (j=G->nodes[i].current_number_of_neighbors;
             j<G->nodes[i].degree;
             ++j)
            {
                neighbor = gsl_rng_get(r) % N;
                while (G->nodes[neighbor].current_number_of_neighbors
                ==G->nodes[neighbor].degree) {
                    neighbor = gsl_rng_get(r) % N;
                }
                G->nodes[i].neighbors[j]=neighbor;
                G->nodes[i].current_number_of_neighbors+=1;
                if (i!=neighbor)
                {
                    neighbors_number_of_neighbors = G->nodes[neighbor].current_number_of_neighbors;
                    G->nodes[neighbor].neighbors[neighbors_number_of_neighbors] = i;
                    G->nodes[neighbor].current_number_of_neighbors+=1;
                }
            }
        }
    }
}

void free_graph (graph* G)
{
    //before we free the "nodes" pointer
    //we must first free each node's associated pointer
    int i;
    for (i=0; i<G->NumNodes; ++i)
        free_node(&G->nodes[i]);
    //now each node's pointers are free, we are done
    free(G->nodes);
}

int ran_scale_free (gsl_rng* r, int k_min, double alpha)
{
    double rand = gsl_rng_uniform(r);
    if (k_min>5)//see arXiv: 0706.1062 (Clauset, Shalizi, & Newman)
        return (int)((k_min-0.5)*pow((1-rand),-1/(alpha-1))+0.5);
    else
    {
        double x1,x2,xp;
        x2=k_min;
        double Px=2;
        //double up
       while (Px>1-rand)
       {
           x1=x2;	   
           x2=x1*2;

           Px = gsl_sf_hzeta(alpha,x2)/gsl_sf_hzeta(alpha,k_min);//correct?
								//plot degree dist
        }
        //binary search
        while (x2-x1>1)
        {
            xp = x1 + ((x2-x1)/2);
            Px = gsl_sf_hzeta(alpha,xp)/gsl_sf_hzeta(alpha,k_min);//correct?
            if (Px<1-rand) x2=xp;
            
            else x1=xp;
        }
        if ((int) x1 <= NUMBER_OF_NODES) return (int) x1;
	else return NUMBER_OF_NODES;
       // return (int)x1;//I choose the "lower" of the two values
    }
}

