//////////////////////Uniform Mixing Hypothesis Model///////////////////////////
//Written By: Keith Burghardt
//Most Recent Update: 10/9/2013

/*
 This is code for the fraction of infected nodes at each timestep, using the formula:
 
	 \Delta \rho = -R \rho + I <k> \rho (1-\rho)				(1)
 
 (SIS Homogeneous Mixing Hypothesis) where we update continuously.
 
 Code computes behavior space of formula for:
	- I	= I_MIN		:I_STEP_SIZE		:I_MAX,
	- R 	= R_MIN		:R_STEP_SIZE		:R_MAX, 
	- <k>	= DEGREE_MIN	:DEGREE_STEP_SIZE	:DEGREE_MAX

 with NUMBER_OF_TRIALS (make this >= the number of processors).
 
 input definitions:
 	RUN_TIME,
 	NUMBER_OF_NODES,  
 	DEGREE_MIN, DEGREE_MAX  DEGREE_STEP_SIZE;
 	I_MIN,      I_MAX,      I_STEP_SIZE;
 	R_MIN,      R_MAX,      R_STEP_SIZE;
 
 
 output:
	"name.dat": " Degree_min = , Degree_max, Degree_step_size= ,
		 R= ... , I= ... , # Trials =__  \n" 
	then array: "fraction_infected " x Run_Time x # I's x # R's x # Degree steps  
 
 
 NOTES: 
	- FOR BEST QUALITY:
		- compile with "$ gcc -O3 -pthread -lgsl [possible -msse3]
							MixingModels.c -o COMMAND"
		- allocate memory in parallel with Hoard, or similar
	

	- Behavior Space determined by definitions below. 
 
 */
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_sf_log.h>


////////////////////////////////////////////////////////////////////////////////

//EDIT: changed drand_buffer to gsl_rng * r, we are using mt19937 mercenne twister

//Computation Runs for RUN_TIME number of ticks,
//for equilibrium we ignore first 504 ticks
#define RUN_TIME        (4600)
#define IGNORE_TIME     (504)//For Cooley-Turkey method, data is of length 2^12

#define FFT_START       (50)// lowest frequency where pink noise
                             // slope doesn't flatten out
#define FFT_END         (1800)//highest frequency before slope flattens out

#define NUMBER_OF_NODES	(1000)

//behavior space parameters
#define DEGREE_MIN    	(2)
#define DEGREE_MAX    	(6)
#define DEGREE_STEP_SIZE (2)

#define I_MIN          	(0.01f)
#define I_MAX          	(1.0f)
#define I_STEP_SIZE   	(0.01f)

#define R_MIN           (0.2f)
#define R_MAX           (1.0f)
#define R_STEP_SIZE     (0.2f)


#define eps             (0.00001)

#define NUMBER_OF_TRIALS (144)

#define INFECTED        (1)

#define SUSCEPTIBLE     (0)


/*
int I_steps             = ((int)((I_MAX-I_MIN)/I_STEP_SIZE+1+eps));
int R_steps             = ((int)((R_MAX-R_MIN)/R_STEP_SIZE+1+eps));
int Degree_steps        = ((int)((DEGREE_MAX-DEGREE_MIN)/DEGREE_STEP_SIZE+1+eps));
*/

typedef struct 
{
    int                 thread;
    gsl_rng *           r;
    int *               NodeArray;
    double *            FractionInfectedVersusTime;
    double *            Trend;

} thread_args;

void make_thread_args ( thread_args *       args,
                        int                 thread);

void free_thread_args ( thread_args *       args);


//function definitions
void infect (           int *	 			NodeArray_ptr,
                        int 				NUMBER_OF_HEALTHY_NEIGHBORS,
                        float 				I,
                        gsl_rng*            		r);

void recover (          int * 				NodeArray_ptr,
                        int *				NUMBER_INFECTED,
                        float 				R,
                        gsl_rng *       	        r);

void run_experiment (	double * 			FractionInfectedVersusTime_ptr,
                        int            			start,
                     	int * 				NodeArray_ptr,
                     	int 				DEGREE,
                    	float 				I,
                     	float 				R,
                        gsl_rng *           		r);

void* perform_trials (	void* trial);


void behavior_space (	char* 				file);

void time_and_run_behavior_space();

////////////////////////////////////////////////////////////////////////////////

void seed_rand(int thread_n, gsl_rng* r);


int main(int argc, char** argv)
{
    
    time_and_run_behavior_space();
    
    return 0;
}
void time_and_run_behavior_space()

{
    
    clock_t start = clock();//timer
    clock_t end;
    clock_t time;
    struct timeval actual_start;
    struct timeval actual_end;
    int actual_time;
    gettimeofday(&actual_start,NULL);
    
    //write to this file
    char *file = "/export/data/ccbdata/keith/SISm=2:2:6N=10^5R=0.2:0.2:1.0,I=0.01:0.01:1.0,48TrialsEach2.dat";

    behavior_space(file);
    end=clock();
    time = end-start;
    gettimeofday(&actual_end,NULL);
    actual_time = actual_end.tv_sec-actual_start.tv_sec;
    printf("Total Time: %ld ms (clock) or %i s (absolute)\n",time/(CLOCKS_PER_SEC/1000),actual_time);
    
}


void behavior_space (char* file)
{
    //we make several for loops to observe entire behavior space, e.g.
    //      -degree
    //      -infection probability (I)
    //      -recovery probability (R)
    FILE * p = NULL;
    
    p = fopen(file, "w");//in order to write everything on ONE text file, we open the file here
    if(p==NULL)
    {
	printf("Error opening file: %s\n",file);
        exit(1);
    }
    
    fprintf(
	p,
	"Degree:%i:%i:%i, R=%f:%f:%f, I=%f:%f:%f, Trials=%i\n",
	DEGREE_MIN,	DEGREE_STEP_SIZE,	DEGREE_MAX,
	R_MIN,		R_STEP_SIZE,		R_MAX,
	I_MIN,		I_STEP_SIZE,		I_MAX,
	NUMBER_OF_TRIALS);
    
    pthread_t threads [NUMBER_OF_TRIALS];
    thread_args trial [NUMBER_OF_TRIALS];

    int rc;
    int TRIAL;
    for (TRIAL=0; TRIAL<NUMBER_OF_TRIALS; ++TRIAL)
    {
        make_thread_args(&trial[TRIAL],TRIAL);
        //seed_rand(TRIAL, &trial[TRIAL].drand_buffer);
        rc = pthread_create(&threads[TRIAL],
                            NULL,
                            perform_trials,
                            (void *) &trial[TRIAL]);
        assert(0 == rc);

    }
    int I_steps             = ((int)((I_MAX-I_MIN)/I_STEP_SIZE+1+eps));
    int R_steps             = ((int)((R_MAX-R_MIN)/R_STEP_SIZE+1+eps));
    int Degree_steps        = ((int)((DEGREE_MAX-DEGREE_MIN)/DEGREE_STEP_SIZE+1+eps));   
    int BEHAVIOR_SPACE      =  (RUN_TIME*(I_steps*R_steps*Degree_steps));
    
    for (TRIAL = 0; TRIAL<NUMBER_OF_TRIALS; ++TRIAL)
    {
    	rc= pthread_join(threads[TRIAL],(void *)&trial[TRIAL]);
     	assert(0 == rc);
    }
    
    int i,R,K;
    double slope, average;
    for(K=0; K<Degree_steps;++K)
    {
        fprintf(p,"\n");
        for (R=0; R<R_steps;++R)
        {
            fprintf(p,"\n");
            for (i=0; i<I_steps;++i)
            {
                fprintf(p,"\n");
            
                for (TRIAL = 0; TRIAL<NUMBER_OF_TRIALS; ++TRIAL)
                {
		    slope = trial[TRIAL].Trend[i + R*I_steps+ K*R_steps*I_steps];
		    average = trial[TRIAL].FractionInfectedVersusTime[RUN_TIME
				*(R*I_steps+i)+IGNORE_TIME]/(RUN_TIME-IGNORE_TIME);
                    fprintf(p,"%lf %lf\n", average, slope);
                }
            }
        }
        
    }
/*
    fprintf(p,"\n\n");
    for (TRIAL = 0; TRIAL<NUMBER_OF_TRIALS; ++TRIAL)
    {
        int i;
        for(i=0; i<BEHAVIOR_SPACE;++i)
       	    fprintf(p,"%lf ",*(trial[TRIAL].FractionInfectedVersusTime+i));
        free_thread_args(&trial[TRIAL]);
    }
  */ 
    printf("\nWritten Successfully to: %s\n",file);
    fclose(p);
}

////////////////////////////////////////////////////////////
//following function was partly barrowed from stackoverflow forum
void seed_rand(int thread_n, gsl_rng* r)
{
    struct timeval tv;
    
    gettimeofday(&tv, NULL);
    gsl_rng_set(r,tv.tv_sec * thread_n + tv.tv_usec);
}
////////////////////////////////////////////////////////////

void* perform_trials(void* trial)
{
    thread_args* t = ((thread_args *) trial);//equate pointers
    
    ////////////////////VARIABLES FOR DATA ANALYSIS/////////////////////
    size_t STRIDE =1;//steps of size "double"
    double * fft;
    //allocate appropriate memory
    double * x = malloc(sizeof(double)*(RUN_TIME-IGNORE_TIME)/2);
    double * y = malloc(sizeof(double)*(RUN_TIME-IGNORE_TIME)/2);
    double constant,slope;//best fit parameters
    double cov00, cov01, cov11;//covariance matrix
    double sumsq; //sum of the square of all terms
    int count=0;
    //////////////////////////////////////////////////////////////////////
    int I_steps             = ((int)((I_MAX-I_MIN)/I_STEP_SIZE+1+eps));
    int R_steps             = ((int)((R_MAX-R_MIN)/R_STEP_SIZE+1+eps));
    int Degree_steps        = ((int)((DEGREE_MAX-DEGREE_MIN)/DEGREE_STEP_SIZE+1+eps));
    int BEHAVIOR_SPACE      =  (RUN_TIME*(I_steps*R_steps*Degree_steps));


    int DEGREE;
    for (DEGREE = DEGREE_MIN; DEGREE<=DEGREE_MAX; DEGREE +=DEGREE_STEP_SIZE)
    {
	float R;
        for (R = R_MIN; R<=R_MAX+eps;R+=R_STEP_SIZE)//R ={0.1...1.0} in steps of 0.1
        {
    	    float I;
            for (I=I_MIN; I<=I_MAX+eps; I+=I_STEP_SIZE)//I = {0.0...1.0} in steps of 0.01
            {
                // To find correct position to record values for the
                // FractionInfectedVersusTime array, we use
                // the following variables:

                int         current_I_step         = (int)((I-I_MIN)/I_STEP_SIZE+eps);
                int         current_R_step         = (int)((R-R_MIN)/R_STEP_SIZE+eps);
                int         current_Degree_step    = (int)((DEGREE-DEGREE_MIN)/DEGREE_STEP_SIZE+eps);
                int         Beginning_Of_Array     = RUN_TIME*(current_I_step +
                                                        I_steps*current_R_step +
                                                        I_steps*R_steps*current_Degree_step);

    	        run_experiment (t->FractionInfectedVersusTime,
                                Beginning_Of_Array,
                                t->NodeArray,
                                DEGREE,
                                I,
                                R,
                                t->r);
                //Given "FractionInfectedVersusTime" we
                    // Take the FFT from "IGNORE_TIME"=>"RUN_TIME"
                    // Take the absolute value^2 of the FFT
                    // Make a best fit line of: {log(i),FFT[i]}
                    // Record the slope into an array (*(t->Trend+i))
                    // Write array to file
                
                
                //take on values of "fraction infected"
                //from TIME_IGNORE to the end of the run
		//ONLY if the infection lasts to the very end
		//where the end is at RUN_TIME-1
		if(t->FractionInfectedVersusTime[Beginning_Of_Array+RUN_TIME-1]!=0)
                {
		    fft = t->FractionInfectedVersusTime+Beginning_Of_Array+IGNORE_TIME;
		    int n = RUN_TIME-IGNORE_TIME;               
                    gsl_fft_real_radix2_transform (fft, STRIDE, RUN_TIME-IGNORE_TIME);
		    //printf("avg: %lf \n",fft[0]/n);
                    int j;
                    for (j=1; j<n/2;j++)//we skip j=0 to avoid "log(0)"
                    {
                        x[j] = gsl_sf_log ((double) j);
                        //we take the log of the absolute value of the fft
                        //note that the fft contains the real and complex part
                        //on opposite sizes of the array
	    	        if((fft[j]*fft[j] + fft[n-j]*fft[n-j])>0.0)//log well defined
		        {
			    if(j!=n/2)
                    	        y[j] = gsl_sf_log (fft[j]*fft[j] + fft[n-j]*fft[n-j]);
			    else
			        y[j] = gsl_sf_log(fft[n/2]*fft[n/2]);//imaginary part is 0
		        }
		        else y[j] = -999999;//set to "-infinity"
                     }
               
                     gsl_fit_linear (x+FFT_START, STRIDE,
		   		     y+FFT_START, STRIDE, 
				     FFT_END-FFT_START, 
				     &constant, 
				     &slope, 
				     &cov00, &cov01, &cov11, 
				     &sumsq);
		     //printf("%lf \n", -slope);
                     t->Trend[count] = -slope;
		}
		else//infection died out
		{
		    t->Trend[count] = 0;//0 slope
		    //This sets the average to 0
		    //in the future, we may wish to clean this up
		    t->FractionInfectedVersusTime[Beginning_Of_Array+IGNORE_TIME]=0.0;
		}
		count++;
            }
        }
    }
    // remove allocated memory
    free((double*) x);
    free((double*) y);
}



void run_experiment (double * 		FractionInfectedVersusTime_ptr,
                     int 			start,
                     int * 		NodeArray_ptr,
                     int 			DEGREE,
                     float 			I,
                     float 			R,
                     gsl_rng*       		r)
{
    
    
    double FRACTION_INFECTED       = 0.5;//We infect half of our nodes initially
    double FRACTION_HEALTHY        = 1-FRACTION_INFECTED;
    int   NUMBER_INFECTED         = (int)(FRACTION_INFECTED*NUMBER_OF_NODES);
    int   INITIAL_NUMBER_INFECTED = NUMBER_INFECTED;//(int)(NUMBER_OF_NODES*FRACTION_INFECTED);
    int i;
    for(i = 0; i < NUMBER_OF_NODES; i++)
    {
        if(i<INITIAL_NUMBER_INFECTED)//infect 1/2 of all nodes
            NodeArray_ptr[i] = INFECTED;//Infect 1/2 of all nodes
        else
            NodeArray_ptr[i] = SUSCEPTIBLE;//else set to healthy
    }
    int t;
    for (t=0; t<RUN_TIME; ++t)
    {
        
        if(FRACTION_INFECTED>0.0)
        {
            
            //infect healthy nodes with probability "I", if they are a neighbor of a sick node
            
            int NUMBER_OF_HEALTHY_NEIGHBORS = (int)(DEGREE*FRACTION_HEALTHY*NUMBER_INFECTED);
            infect (NodeArray_ptr,NUMBER_OF_HEALTHY_NEIGHBORS,I,r);

	    //with probability "R",
            //elements in NodeArray recover            
            recover (NodeArray_ptr, &NUMBER_INFECTED, R,r);
            FRACTION_INFECTED = NUMBER_INFECTED/(double)NUMBER_OF_NODES;//reduces floating point errors
            FRACTION_HEALTHY =1-FRACTION_INFECTED;

            //store fraction of infected
	    //"start" is starting position of array
            FractionInfectedVersusTime_ptr[start+t] = FRACTION_INFECTED;
        }
        else//if all nodes are healthy
        {
            FractionInfectedVersusTime_ptr[start+t] = 0.0;
        }
        
    }
    
}

void infect (int* NodeArray_ptr, 
	     int NUMBER_OF_HEALTHY_NEIGHBORS,
	     float I,
	     gsl_rng* r)
{
    int count = 0;//counts healthy neighbors, so we dont infect too many
    double rand;
    int k;
    for(k=0; k<NUMBER_OF_NODES; ++k)
    {
        if(NodeArray_ptr[k]==SUSCEPTIBLE 
		&& count<NUMBER_OF_HEALTHY_NEIGHBORS)//if a healthy neighbor
        {
            count++;
            double rand = gsl_rng_uniform (r);
            if(rand<I)
                NodeArray_ptr[k]=INFECTED;//infect with probability I
        }            
    }
    
}

void recover (int * NodeArray_ptr, 
	      int *NUMBER_INFECTED, 
	      float R,
	      gsl_rng* r)

{
    *NUMBER_INFECTED = 0;
    double rand;
    int k;
    for(k=0; k<NUMBER_OF_NODES; ++k)
    {
        if (NodeArray_ptr[k]==INFECTED)//if infected
        {
            double rand = gsl_rng_uniform (r);
	   
            if(rand<R)
            {
                NodeArray_ptr[k]=SUSCEPTIBLE;//recover with probability R
            }
            else *NUMBER_INFECTED+=1;//else this is an infected node, so record
        }
    }
}
void make_thread_args (thread_args * args,
                       int thread)
{
    args->thread                    = thread;
    args->r                         = gsl_rng_alloc (gsl_rng_mt19937);
    seed_rand(thread,args->r);
    args->NodeArray                 = malloc(sizeof(int)*NUMBER_OF_NODES);
	//we now allocate memory that's the sie of the behavior space
    int I_steps             = ((int)((I_MAX-I_MIN)/I_STEP_SIZE+1+eps));
    int R_steps             = ((int)((R_MAX-R_MIN)/R_STEP_SIZE+1+eps));
    int Degree_steps        = ((int)((DEGREE_MAX-DEGREE_MIN)/DEGREE_STEP_SIZE+1+eps));
    int BEHAVIOR_SPACE              = (RUN_TIME*(I_steps*R_steps*Degree_steps));
    args->FractionInfectedVersusTime= malloc(sizeof(double)*BEHAVIOR_SPACE);//allocate for all of behavior space
    args->Trend                     = malloc(sizeof(double)*I_steps*R_steps*Degree_steps);
}
void free_thread_args (thread_args * args)
{
    free(args->FractionInfectedVersusTime);
    free(args->NodeArray);
    gsl_rng_free (args->r);
    
}
