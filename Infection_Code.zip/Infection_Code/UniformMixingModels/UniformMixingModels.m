(* ::Package:: *)

SIS\[Alpha]VersusInfectionProbability[m_,NumNodes_:10000]:=Module[
{FractionInfected,FractionHealthy,NodeArray=ConstantArray[0,NumNodes],
HealthyNeighbors,FractionInfectedVersusTime,PSD,lm,TypicalTrend},
	ParallelTable[
	(*Initial Conditions*)
	FractionInfected=0.5;
	NodeArray[[1;;Floor[NumNodes FractionInfected]]]=1;

	FractionInfectedVersusTime=Table[
		If[FractionInfected>0,
			(*Make Infected Nodes Well With Probability R*)
			NodeArray=Table[If[NodeArray[[i]]==1&&RandomReal[]<R,0,
			NodeArray[[i]]],{i,Length[NodeArray]}];

			FractionHealthy=1-(Plus@@NodeArray)/NumNodes;

			(*Assume the fraction of healthy neighbors is proportional
			 to the total fraction of healthy nodes*)
			If[Floor[m (Plus@@NodeArray) FractionHealthy]<NumNodes-Plus@@NodeArray,
				HealthyNeighbors=
					RandomChoice[
						Flatten[Position[NodeArray,0]],
						Floor[m (Plus@@NodeArray) FractionHealthy]
					];,
				HealthyNeighbors=Flatten[Position[NodeArray,0]];
			];

			Do[
				If[RandomReal[]<Pinf,(*With Probability Pinf, infected healthy neighbors*)
					NodeArray[[HealthyNeighbors[[i]]]]=1;
				]
			,{i,Length[HealthyNeighbors]}
			];
			FractionInfected=N[1-FractionHealthy],
			(*All nodes healthy*)
			FractionInfected=0
		]
	,{time,5500}];

	If[FractionInfected!=0,
		PSD=Abs[Fourier[FractionInfectedVersusTime[[400;;Length[FractionInfectedVersusTime]]]]]^2;
		(*PSD Of Signal In Equilibrium*)
	lm=LinearModelFit[Table[{Log[j],Log[PSD[[j]]]},{j,150,2000}],x,x];

	(*Best Fit Slope Of Signal Noise (i.e. best fit \[Alpha], if noise is 1/f^\[Alpha])*)
	TypicalTrend={Pinf,-lm["BestFitParameters"][[2]]},
	TypicalTrend={Pinf,0}
	]
,{R,0.2,1,0.2},{Pinf,0.01,1,0.01}]];


Bass\[Alpha]VersusInfectionProbability[m_,NumNodes_:10000]:=
Module[
	{FractionInfected,FractionHealthy,NodeArray=ConstantArray[0,NumNodes],
	HealthyNeighbors,FractionInfectedVersusTime,
	PSD,lm,TypicalTrend},
	ParallelTable[		
		(*Initial Conditions*)
		FractionInfected=0.5;
		NodeArray[[1;;Floor[NumNodes FractionInfected]]]=1;

		FractionInfectedVersusTime=Table[
			If[FractionInfected>0,
				(*Make Infected Nodes Well With Probability R*)
				NodeArray=Table[If[NodeArray[[i]]==1&&RandomReal[]<R,0,
						NodeArray[[i]]],{i,Length[NodeArray]}];
	 
				FractionHealthy=1-(Plus@@NodeArray)/NumNodes;
	 
			(*Assume the fraction of healthy neighbors is
			 proportional to the total fraction of healthy nodes*)
				If[Floor[m (Plus@@NodeArray) FractionHealthy]<NumNodes-Plus@@NodeArray,
					HealthyNeighbors=
						RandomChoice[
							Flatten[Position[NodeArray,0]],
							Floor[m (Plus@@NodeArray) FractionHealthy]
						];,
					HealthyNeighbors=Flatten[Position[NodeArray,0]];
				];
	 
				Do[
					If[RandomReal[]<v/m,
						NodeArray[[HealthyNeighbors[[i]]]]=1;(*With Probability v/m, infected healthy neighbors*)
						]
				,{i,Length[HealthyNeighbors]}
				];
				FractionInfected=N[1-FractionHealthy],
				(*All nodes healthy*)
				FractionInfected=0
			]
	,{time,5500}];
	
	If[FractionInfected!=0,
	PSD=Abs[Fourier[FractionInfectedVersusTime[[400;;Length[FractionInfectedVersusTime]]]]]^2;
			  (*PSD Of Signal In Equilibrium*)
  
	lm=LinearModelFit[Table[{Log[j],Log[PSD[[j]]]},{j,150,2000}],x,x];
  
	(*Best Fit Slope Of Signal Noise (i.e. best fit \[Alpha], if noise is 1/f^\[Alpha])*)
	TypicalTrend={v,-lm["BestFitParameters"][[2]]},
	TypicalTrend={v,0}
	]
,{R,0.2,1,0.2},{v,0.01,1,0.01}]];

LT\[Alpha]VersusInfectionProbability[m_,NumNodes_:10000]:=
Module[{FractionInfected,FractionHealthy,NodeArray=ConstantArray[0,NumNodes],
HealthyNeighbors,FractionInfectedVersusTime,PSD,lm,TypicalTrend},
	ParallelTable[

	(*Initial Conditions*)
	FractionInfected=0.5;
	NodeArray[[1;;Floor[NumNodes FractionInfected]]]=1;

	FractionInfectedVersusTime=
	Table[
		If[FractionInfected>0,
			(*Make Infected Nodes Well With Probability R*)
			NodeArray=Table[If[NodeArray[[i]]==1&&RandomReal[]<R,0,
			NodeArray[[i]]],{i,Length[NodeArray]}];

			FractionHealthy=1-(Plus@@NodeArray)/NumNodes;

			(*Assume the fraction of healthy neighbors is
			 proportional to the total fraction of healthy nodes*)
			If[Floor[m (Plus@@NodeArray) FractionHealthy]<NumNodes-Plus@@NodeArray,
				HealthyNeighbors=
				RandomChoice[
					Flatten[Position[NodeArray,0]],
					Floor[m (Plus@@NodeArray) FractionHealthy]
				];,
			HealthyNeighbors=Flatten[Position[NodeArray,0]];
			];

		Do[
				If[1-FractionHealthy>threshold,(*no infection until we are above the threshold*)
				NodeArray[[HealthyNeighbors[[i]]]]=1;(*With Probability Pinf, infected healthy neighbors*)
				]
			,{i,Length[HealthyNeighbors]}];
			FractionInfected=N[1-FractionHealthy]
			,FractionInfected=0(*All Nodes Healthy. Dont waste time on computations*)
			]
	,{time,5500}];

	If[FractionInfected!=0,
		PSD=Abs[Fourier[FractionInfectedVersusTime[[400;;Length[FractionInfectedVersusTime]]]]]^2;
		(*PSD Of Signal In Equilibrium*)
	
		lm=LinearModelFit[Table[{Log[j],Log[PSD[[j]]]},{j,150,2000}],x,x];

		(*Best Fit Slope Of Signal Noise (i.e. best fit \[Alpha], if noise is 1/f^\[Alpha])*)
		TypicalTrend={threshold,-lm["BestFitParameters"][[2]]},
		TypicalTrend={threshold,0}
		],
{R,0.2,1,0.2},{threshold,0.01,1,0.01}]];

ICS\[Alpha]VersusInfectionProbability[m_, NumNodes_: 10000] := 
Module[{FractionInfected, FractionHealthy, NodeArray= ConstantArray[0, NumNodes], 
    HealthyNeighbors, FractionInfectedVersusTime, PSD, lm, 
    TypicalTrend}, 
	ParallelTable[

	    (*Initial Conditions*)
		FractionInfected = 0.5;
		NodeArray[[1 ;; Floor[NumNodes FractionInfected]]] = 1;
		FractionInfectedVersusTime = 
		Table[
			If[FractionInfected > 0,
				(*Make Infected Nodes Well With Probability R*)
				FractionHealthy = 1 - (Plus @@ Abs[NodeArray])/NumNodes;
				(*Assume the fraction of healthy neighbors is proportional to \
				the total fraction of healthy nodes*)
				If[Floor[m (Plus @@ (NodeArray /. {-1 -> 0})) FractionHealthy] < 
				(NumNodes - Plus @@ Abs[NodeArray]), 
					HealthyNeighbors = 
					RandomChoice[Flatten[Position[NodeArray, 0]], 
				          Floor[m (Plus @@ (NodeArray /. {-1 ->0})) FractionHealthy]];, 
					HealthyNeighbors = Flatten[Position[NodeArray, 0]];
				];
				(*Make Removed Nodes Healthy With Probability R,
					and Make Currently Infected Nodes Removed*)
				NodeArray = 
				Table[
					If[NodeArray[[i]] == -1, 
						If[RandomReal[] < R, 0, NodeArray[[i]]], 
						NodeArray[[i]]],
					{i, NumNodes}] /. {1 -> -1};
				(*Infect Healthy Nodes*)
				Do[
					If[Position[HealthyNeighbors, i] != {},(*Neighbor Healthy*)
						If[RandomReal[] < Pinf, NodeArray[[i]] = 1;]
						(*With Probability Pinf,infected healthy neighbors*)
					];,
				{i,NumNodes}];
				(*Remove Infected Nodes*)
				FractionInfected = N[Plus @@ (NodeArray /. {-1 -> 0})/NumNodes], 
				FractionInfected = 0(*All Nodes Healthy.Dont waste time on computations*)
			], 
		{time, 5500}];
		If[FractionInfected != 0,
		PSD = 
		Abs[Fourier[FractionInfectedVersusTime[[400 ;; Length[FractionInfectedVersusTime]]]]]^2;
		(*PSD Of Signal In Equilibrium*)
		lm = LinearModelFit[
		Table[{Log[j], Log[PSD[[j]]]}, {j, 150, 2000}], x, x];
		(*Best Fit Slope Of Signal Noise (i.e.best fit \[Alpha],
		if noise is 1/f^\[Alpha])*)
		TypicalTrend = {Pinf, -lm["BestFitParameters"][[2]], 
			Position[PSD, Max[PSD[[1 ;; 2500]]]]}, TypicalTrend = {Pinf, 0}]
    , {R, 0.2, 1, 0.2}, {Pinf, 0.01, 1, 0.1}
	]
];
