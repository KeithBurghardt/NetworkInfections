/*
******************************************************
SIS Infection Header for SIS_Poisson.c 

Created By: Keith Burghardt
******************************************************
*/
#ifndef _SIS_Poisson_h
#define _SIS_Poisson_h


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_sf_log.h>

////////////////////////////////////////////////////////////////////////////////

typedef struct
{
    int                 ID;
    int                 degree;
    int                 current_number_of_neighbors;
    int *               neighbors;
    int                 infected;
} node;

typedef struct
{
    int                 NumNodes;
    node*               nodes;
    double              average_degree;
} graph;

typedef struct
{
    int                 thread;
    gsl_rng *           r;
    graph               G;
    double *            FractionInfectedVersusTime;
    double *            Trend;
    
} thread_args;

void make_node (        node*       n,
                        int         ID,
                        int         deg);

void free_node (        node*       N);

void make_graph (       graph*      G,
                        int         N,
                        double      av_deg,
                        gsl_rng*    r);

void free_graph (       graph*      G);

void make_thread_args ( thread_args * args,
                        int           thread,
                        int 	      N,
                        int           av_deg);

void free_thread_args ( thread_args * args);

//function definitions
void infect (           graph *		G,
                        float 		Th);

void recover (          graph *     	G,
                        int *       	NUMBER_INFECTED,
                        float       	R,
                        gsl_rng*    	r);

void run_experiment (	double * 	FractionInfectedVersusTime_ptr,
                        int       	start,
                        graph *     	G,
                        float 		Th,
                        float 		R,
                        gsl_rng *   	r);

void* perform_trials (	void *      	trial);


void behavior_space (	char* 		file);

void time_and_run_behavior_space();

void seed_rand(         int         	thread_n,
                        gsl_rng *   	r);


#endif
